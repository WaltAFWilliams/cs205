# Task 2b
	* The Model name is : Intel(R) Xeon(R) CPU E5-2683 v4 @ 2.10GHz and as can be seen, its manufacturer is intel. 
	* According to the terminal output there are 32 cores available for me to use.
	* Each cpu has 16 cores
	* There are 2 cpus on my node
	* each core has access to 40MB of memory
	* L1 cache size is 32kb, L2 cache size is 256kb, L3 cache size is 40 MB
	* L3 cache is shared among cpu cores
	* Some cores are marked in red because the they are not currently being used by my process.
	* The main difference I see between c1 and c32 are that none of the cpu cores are colored in red for c32

